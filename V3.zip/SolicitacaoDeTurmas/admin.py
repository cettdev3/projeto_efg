from django.contrib import admin
# from .models import Cidade, Rede, Escola

# admin.site.register(Cidade)
# admin.site.register(Rede)
# admin.site.register(Escola)
